
export interface User {
  id: string;
  emailOrPhone: string;
}

export interface Plan {
  id: number;
  name: string;
  amount: number;
  dailyReturnPercentage: number;
}

export interface Investment {
  planId: number;
  initialDeposit: number;
  startDate: number; // UTC timestamp
}

export interface PastInvestment {
  planId: number;
  initialDeposit: number;
  startDate: number;
  endDate: number;
  finalRevenue: number;
}

export interface Transaction {
  id: string;
  type: 'Deposit' | 'Withdrawal';
  amount: number;
  date: number; // UTC timestamp
  details: {
    // For Deposit
    payerAccountName?: string;
    payerBank?: string;
    planName?: string;
    // For Withdrawal
    beneficiaryAccountName?: string;
    beneficiaryBank?: string;
    beneficiaryAccountNumber?: string;
  };
}


export interface AuthContextType {
  user: User | null;
  investment: Investment | null;
  investmentHistory: PastInvestment[];
  transactions: Transaction[];
  login: (emailOrPhone: string) => void;
  logout: () => void;
  startInvestment: (plan: Plan, payerDetails: { payerAccountName: string, payerBank: string }) => void;
  withdraw: (amount: number, withdrawalDetails: { bankName: string, accountNumber: string, accountName: string }) => void;
  balance: {
    total: number;
    revenue: number;
  };
}

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { INVESTMENT_PLANS, MOCK_ACCOUNT_DETAILS, WITHDRAWAL_THRESHOLD } from '../constants';
import { Plan } from '../types';
import PlanCard from '../components/PlanCard';
import Modal from '../components/Modal';
import TransactionHistory from '../components/TransactionHistory';
import InvestmentHistory from '../components/InvestmentHistory';

const NairaFormatter = new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 2,
});

const DashboardPage: React.FC = () => {
    const { user, logout, investment, startInvestment, balance, withdraw } = useAuth();
    const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
    const [isPaymentModalOpen, setPaymentModalOpen] = useState(false);
    const [isWithdrawModalOpen, setWithdrawModalOpen] = useState(false);
    
    // Withdraw state
    const [withdrawAmount, setWithdrawAmount] = useState('');
    const [withdrawalBankName, setWithdrawalBankName] = useState('');
    const [withdrawalAccountNumber, setWithdrawalAccountNumber] = useState('');
    const [withdrawalAccountName, setWithdrawalAccountName] = useState('');

    // Payment state
    const [transactionCode, setTransactionCode] = useState<string | null>(null);
    const [codeExpiresAt, setCodeExpiresAt] = useState<number | null>(null);
    const [countdown, setCountdown] = useState('');
    const [paymentStep, setPaymentStep] = useState<'instructions' | 'confirmation'>('instructions');
    const [payerAccountName, setPayerAccountName] = useState('');
    const [payerBank, setPayerBank] = useState('');

    const activePlan = investment ? INVESTMENT_PLANS.find(p => p.id === investment.planId) : null;

    const handleSelectPlan = (plan: Plan) => {
        if (!user) return;
        setSelectedPlan(plan);
        setPaymentStep('instructions');
        setPayerAccountName('');
        setPayerBank('');

        const code = `${user.emailOrPhone.slice(0, 3).toUpperCase()}${Date.now().toString().slice(-5)}`;
        setTransactionCode(code);
        
        const expirationTime = Date.now() + 30 * 60 * 1000;
        setCodeExpiresAt(expirationTime);
        
        setPaymentModalOpen(true);
    };
    
    useEffect(() => {
        if (!codeExpiresAt || !isPaymentModalOpen) return;

        const intervalId = setInterval(() => {
            const now = Date.now();
            const timeLeft = Math.round((codeExpiresAt - now) / 1000);

            if (timeLeft <= 0) {
                clearInterval(intervalId);
                setCountdown('Expired');
                setTransactionCode(null);
                setCodeExpiresAt(null);
            } else {
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                setCountdown(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
            }
        }, 1000);

        return () => clearInterval(intervalId);
    }, [codeExpiresAt, isPaymentModalOpen]);

    const handleProceedToConfirmation = () => {
        if (transactionCode) {
            setPaymentStep('confirmation');
        } else {
            alert("Transaction code has expired. Please select a plan again.");
            closePaymentModal();
        }
    };
    
    const handleFinalizePayment = () => {
        if (!payerAccountName || !payerBank) {
            alert('Please provide the account name and bank used for payment.');
            return;
        }
        
        if (selectedPlan) {
            startInvestment(selectedPlan, { payerAccountName, payerBank });
        } else {
            alert("An error occurred. Please try again.");
        }
        closePaymentModal();
    };
    
    const closePaymentModal = () => {
        setPaymentModalOpen(false);
        setSelectedPlan(null);
        setTransactionCode(null);
        setCodeExpiresAt(null);
        setPaymentStep('instructions');
        setPayerAccountName('');
        setPayerBank('');
    };

    const handleOpenWithdrawModal = () => {
        setWithdrawAmount('');
        setWithdrawalBankName('');
        setWithdrawalAccountNumber('');
        setWithdrawalAccountName('');
        setWithdrawModalOpen(true);
    };
    
    const handleWithdraw = () => {
        const amount = parseFloat(withdrawAmount);
        if(isNaN(amount) || amount <= 0) {
            alert("Please enter a valid amount.");
            return;
        }
        if(!withdrawalBankName || !withdrawalAccountNumber || !withdrawalAccountName) {
            alert("Please fill in all your bank details.");
            return;
        }
        if (amount < WITHDRAWAL_THRESHOLD) {
            alert(`Minimum withdrawal amount is ${NairaFormatter.format(WITHDRAWAL_THRESHOLD)}`);
            return;
        }
        if (amount > balance.revenue) {
            alert(`You can only withdraw up to your available revenue of ${NairaFormatter.format(balance.revenue)}`);
            return;
        }
        
        withdraw(amount, {
            bankName: withdrawalBankName,
            accountNumber: withdrawalAccountNumber,
            accountName: withdrawalAccountName
        });
        setWithdrawModalOpen(false);
    };
    
    const isWithdrawalFormValid = () => {
        const amount = parseFloat(withdrawAmount);
        return !isNaN(amount) && amount > 0 && withdrawalBankName && withdrawalAccountNumber && withdrawalAccountName;
    }

    return (
        <div className="min-h-screen bg-black">
            <header className="bg-gray-900 shadow-md">
                <div className="container mx-auto px-6 py-4 flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-purple-500 dark:text-purple-400">Elysian Yield</h1>
                    <div className="flex items-center">
                        <span className="text-gray-300 mr-4">Welcome, {user?.emailOrPhone}</span>
                        <button onClick={logout} className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                            Logout
                        </button>
                    </div>
                </div>
            </header>

            <main className="container mx-auto px-6 py-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="col-span-1 md:col-span-1 bg-gray-900 rounded-lg shadow-lg p-6 text-center">
                        <h3 className="text-lg font-medium text-gray-400">Total Balance</h3>
                        <p className="text-4xl font-bold text-purple-500 dark:text-purple-400 mt-2">{NairaFormatter.format(balance.total)}</p>
                    </div>
                    <div className="col-span-1 md:col-span-1 bg-gray-900 rounded-lg shadow-lg p-6 text-center">
                         <h3 className="text-lg font-medium text-gray-400">Initial Deposit</h3>
                        <p className="text-4xl font-bold text-gray-200 mt-2">{NairaFormatter.format(investment?.initialDeposit || 0)}</p>
                    </div>
                    <div className="col-span-1 md:col-span-1 bg-gray-900 rounded-lg shadow-lg p-6 text-center">
                         <h3 className="text-lg font-medium text-gray-400">Total Revenue</h3>
                        <p className="text-4xl font-bold text-cyan-400 dark:text-cyan-300 mt-2">{NairaFormatter.format(balance.revenue)}</p>
                    </div>
                </div>

                {investment ? (
                     <div className="bg-gray-900 rounded-lg shadow-lg p-8 text-center mb-8">
                        <h2 className="text-2xl font-bold mb-4">Your Active Plan: {activePlan?.name}</h2>
                        <p className="text-lg text-gray-300 mb-6">Your daily revenue growth is in progress. You can withdraw once your revenue reaches {NairaFormatter.format(WITHDRAWAL_THRESHOLD)}.</p>
                        <button 
                            onClick={handleOpenWithdrawModal}
                            disabled={balance.revenue < WITHDRAWAL_THRESHOLD}
                            className="px-8 py-3 font-bold text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition duration-300"
                        >
                            Withdraw Funds
                        </button>
                         <p className={`mt-2 text-sm ${balance.revenue < WITHDRAWAL_THRESHOLD ? 'text-red-500' : 'text-purple-400'}`}>
                            {balance.revenue < WITHDRAWAL_THRESHOLD ? 
                             `You need ${NairaFormatter.format(WITHDRAWAL_THRESHOLD - balance.revenue)} more to withdraw.` :
                             `You are eligible to withdraw.`}
                         </p>
                    </div>
                ) : (
                    <div className="mb-8">
                        <h2 className="text-3xl font-bold text-center mb-8">Choose an Investment Plan</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                            {INVESTMENT_PLANS.map(plan => (
                                <PlanCard key={plan.id} plan={plan} onSelect={handleSelectPlan} />
                            ))}
                        </div>
                    </div>
                )}
                
                <div className="space-y-8">
                    <TransactionHistory />
                    <InvestmentHistory />
                </div>

            </main>

            <Modal isOpen={isPaymentModalOpen} onClose={closePaymentModal}>
                {paymentStep === 'instructions' ? (
                     <div className="p-4">
                        <h3 className="text-2xl font-bold text-center mb-4">Payment Instructions</h3>
                        <p className="text-center text-gray-300 mb-6">To activate your <span className="font-bold">{selectedPlan?.name}</span>, please make a payment of <span className="font-bold text-purple-400">{NairaFormatter.format(selectedPlan?.amount || 0)}</span> to the account below:</p>
                        <div className="bg-gray-800 rounded-lg p-4 space-y-2 mb-6">
                            <p><span className="font-semibold">Bank:</span> {MOCK_ACCOUNT_DETAILS.bankName}</p>
                            <p><span className="font-semibold">Account Number:</span> {MOCK_ACCOUNT_DETAILS.accountNumber}</p>
                            <p><span className="font-semibold">Account Name:</span> {MOCK_ACCOUNT_DETAILS.accountName}</p>
                        </div>

                        <div className="bg-purple-900/30 border border-purple-500 rounded-lg p-4 text-center">
                            <p className="text-sm text-gray-300 mb-2">Use this code in your payment narration/description:</p>
                            <p className="text-3xl font-mono tracking-widest bg-gray-900 inline-block p-2 rounded-md">{transactionCode || '---'}</p>
                            <p className={`mt-2 font-semibold ${countdown === 'Expired' ? 'text-red-500' : 'text-purple-400'}`}>
                               {transactionCode ? `Code expires in: ${countdown}` : 'Code has expired.'}
                            </p>
                        </div>

                        <div className="mt-8 flex justify-center">
                            <button 
                                onClick={handleProceedToConfirmation} 
                                className="px-6 py-3 font-bold text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition duration-300"
                                disabled={!transactionCode}
                            >
                                I Have Made Payment
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="p-4">
                        <h3 className="text-2xl font-bold text-center mb-4">Confirm Your Payment</h3>
                        <p className="text-center text-gray-300 mb-6">Please provide the details of the account you used to make the payment.</p>
                        <form onSubmit={(e) => { e.preventDefault(); handleFinalizePayment(); }} className="space-y-4">
                            <div>
                                <label className="text-sm font-medium text-gray-300" htmlFor="payerAccountName">
                                    Account Name Used for Payment
                                </label>
                                <input
                                    id="payerAccountName"
                                    type="text"
                                    value={payerAccountName}
                                    onChange={(e) => setPayerAccountName(e.target.value)}
                                    className="w-full px-4 py-2 mt-2 text-gray-200 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                    placeholder="e.g., John Doe"
                                    required
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium text-gray-300" htmlFor="payerBank">
                                    Bank Name Used for Payment
                                </label>
                                <input
                                    id="payerBank"
                                    type="text"
                                    value={payerBank}
                                    onChange={(e) => setPayerBank(e.target.value)}
                                    className="w-full px-4 py-2 mt-2 text-gray-200 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                    placeholder="e.g., Zenith Bank"
                                    required
                                />
                            </div>
                            <div className="pt-4 flex justify-center">
                                <button 
                                    type="submit"
                                    className="w-full px-6 py-3 font-bold text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition duration-300"
                                    disabled={!payerAccountName || !payerBank}
                                >
                                    Submit Confirmation
                                </button>
                            </div>
                        </form>
                    </div>
                )}
            </Modal>
            
            <Modal isOpen={isWithdrawModalOpen} onClose={() => setWithdrawModalOpen(false)}>
                <div className="p-4">
                    <h3 className="text-2xl font-bold text-center mb-4">Withdraw Funds</h3>
                    <p className="text-center text-gray-300 mb-2">Available for withdrawal: <span className="font-bold text-cyan-400">{NairaFormatter.format(balance.revenue)}</span></p>
                    <p className="text-center text-xs text-gray-400 mb-6">Minimum withdrawal is {NairaFormatter.format(WITHDRAWAL_THRESHOLD)}.</p>
                    <form onSubmit={(e) => { e.preventDefault(); handleWithdraw(); }} className="space-y-4">
                         <div>
                             <label className="text-sm font-medium text-gray-300" htmlFor="withdrawAmount">Amount</label>
                             <input
                                id="withdrawAmount"
                                type="number"
                                value={withdrawAmount}
                                onChange={(e) => setWithdrawAmount(e.target.value)}
                                className="w-full px-4 py-2 mt-1 text-gray-200 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                placeholder="Enter amount to withdraw"
                                required
                             />
                         </div>
                         <div>
                             <label className="text-sm font-medium text-gray-300" htmlFor="withdrawalBankName">Bank Name</label>
                             <input
                                id="withdrawalBankName"
                                type="text"
                                value={withdrawalBankName}
                                onChange={(e) => setWithdrawalBankName(e.target.value)}
                                className="w-full px-4 py-2 mt-1 text-gray-200 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                placeholder="e.g., Zenith Bank"
                                required
                             />
                         </div>
                         <div>
                             <label className="text-sm font-medium text-gray-300" htmlFor="withdrawalAccountNumber">Account Number</label>
                             <input
                                id="withdrawalAccountNumber"
                                type="text"
                                value={withdrawalAccountNumber}
                                onChange={(e) => setWithdrawalAccountNumber(e.target.value)}
                                className="w-full px-4 py-2 mt-1 text-gray-200 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                placeholder="0123456789"
                                required
                             />
                         </div>
                         <div>
                             <label className="text-sm font-medium text-gray-300" htmlFor="withdrawalAccountName">Account Name</label>
                             <input
                                id="withdrawalAccountName"
                                type="text"
                                value={withdrawalAccountName}
                                onChange={(e) => setWithdrawalAccountName(e.target.value)}
                                className="w-full px-4 py-2 mt-1 text-gray-200 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                placeholder="e.g., John Doe"
                                required
                             />
                         </div>
                         <div className="pt-4">
                            <button 
                                type="submit" 
                                className="w-full px-6 py-3 font-bold text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition duration-300"
                                disabled={!isWithdrawalFormValid()}
                            >
                                Confirm Withdrawal
                            </button>
                         </div>
                    </form>
                </div>
            </Modal>
        </div>
    );
};

export default DashboardPage;

import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { INVESTMENT_PLANS } from '../constants';

const NairaFormatter = new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 2,
});

const InvestmentHistory: React.FC = () => {
    const { investmentHistory } = useAuth();

    return (
        <div className="bg-gray-900 rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4 text-gray-200">Past Investments</h2>
            {investmentHistory.length === 0 ? (
                <p className="text-gray-400 text-center py-4">You have no past investment records.</p>
            ) : (
                <div className="overflow-x-auto">
                    <table className="min-w-full text-sm text-left text-gray-400">
                        <thead className="text-xs text-gray-300 uppercase bg-gray-800">
                            <tr>
                                <th scope="col" className="px-6 py-3">Plan Name</th>
                                <th scope="col" className="px-6 py-3">Initial Deposit</th>
                                <th scope="col" className="px-6 py-3">Start Date</th>
                                <th scope="col" className="px-6 py-3">End Date</th>
                                <th scope="col" className="px-6 py-3">Revenue Earned</th>
                            </tr>
                        </thead>
                        <tbody>
                            {investmentHistory.map((inv) => {
                                const plan = INVESTMENT_PLANS.find(p => p.id === inv.planId);
                                return (
                                     <tr key={inv.endDate} className="bg-gray-900 border-b border-gray-700 hover:bg-gray-800">
                                        <td className="px-6 py-4 font-medium text-gray-200">{plan?.name || 'Unknown Plan'}</td>
                                        <td className="px-6 py-4">{NairaFormatter.format(inv.initialDeposit)}</td>
                                        <td className="px-6 py-4">{new Date(inv.startDate).toLocaleString()}</td>
                                        <td className="px-6 py-4">{new Date(inv.endDate).toLocaleString()}</td>
                                        <td className="px-6 py-4 font-medium text-cyan-400">
                                            {NairaFormatter.format(inv.finalRevenue)}
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default InvestmentHistory;
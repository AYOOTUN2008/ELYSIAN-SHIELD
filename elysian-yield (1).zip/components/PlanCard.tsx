import React from 'react';
import { Plan } from '../types';

interface PlanCardProps {
  plan: Plan;
  onSelect: (plan: Plan) => void;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, onSelect }) => {
  return (
    <div className="bg-gray-900 rounded-xl shadow-lg p-6 flex flex-col justify-between items-center transform hover:scale-105 transition-transform duration-300 ease-in-out">
      <div className="text-center">
        <h3 className="text-2xl font-bold text-purple-500 dark:text-purple-400">{plan.name}</h3>
        <p className="text-4xl font-extrabold my-4 text-gray-200">
          ₦{plan.amount.toLocaleString()}
        </p>
        <p className="text-gray-400">Initial Deposit</p>
      </div>
      <div className="text-center my-6">
        <p className="text-lg font-semibold text-gray-300">
          Daily Return: <span className="text-purple-400">{(plan.dailyReturnPercentage * 100)}%</span>
        </p>
         <p className="text-md text-gray-400">
            Earn ₦{(plan.amount * plan.dailyReturnPercentage).toLocaleString()} daily
        </p>
      </div>
      <button
        onClick={() => onSelect(plan)}
        className="w-full px-6 py-3 font-bold text-white bg-purple-600 rounded-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition duration-300 ease-in-out"
      >
        Choose Plan
      </button>
    </div>
  );
};

export default PlanCard;
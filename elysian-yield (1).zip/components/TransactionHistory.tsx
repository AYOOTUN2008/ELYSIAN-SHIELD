import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const NairaFormatter = new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 2,
});

const TransactionHistory: React.FC = () => {
    const { transactions } = useAuth();

    return (
        <div className="bg-gray-900 rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4 text-gray-200">Transaction History</h2>
            {transactions.length === 0 ? (
                <p className="text-gray-400 text-center py-4">No transactions yet.</p>
            ) : (
                <div className="overflow-x-auto">
                    <table className="min-w-full text-sm text-left text-gray-400">
                        <thead className="text-xs text-gray-300 uppercase bg-gray-800">
                            <tr>
                                <th scope="col" className="px-6 py-3">Date</th>
                                <th scope="col" className="px-6 py-3">Type</th>
                                <th scope="col" className="px-6 py-3">Amount</th>
                                <th scope="col" className="px-6 py-3">Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            {transactions.map((tx) => (
                                <tr key={tx.id} className="bg-gray-900 border-b border-gray-700 hover:bg-gray-800">
                                    <td className="px-6 py-4">{new Date(tx.date).toLocaleString()}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                            tx.type === 'Deposit' 
                                            ? 'bg-green-900 text-green-300' 
                                            : 'bg-red-900 text-red-300'
                                        }`}>
                                            {tx.type}
                                        </span>
                                    </td>
                                    <td className={`px-6 py-4 font-medium ${
                                        tx.type === 'Deposit' ? 'text-green-400' : 'text-red-400'
                                    }`}>
                                        {tx.type === 'Deposit' ? '+' : '-'}{NairaFormatter.format(tx.amount)}
                                    </td>
                                    <td className="px-6 py-4">
                                        {tx.type === 'Deposit' ? (
                                            <span>
                                                Plan: <strong>{tx.details.planName}</strong><br />
                                                From: {tx.details.payerAccountName} ({tx.details.payerBank})
                                            </span>
                                        ) : (
                                            <span>
                                                To: {tx.details.beneficiaryAccountName}<br />
                                                ({tx.details.beneficiaryBank} - {tx.details.beneficiaryAccountNumber})
                                            </span>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default TransactionHistory;

import { Plan } from './types';

export const INVESTMENT_PLANS: Plan[] = [
  { id: 1, name: 'Bronze Plan', amount: 1500, dailyReturnPercentage: 0.25 },
  { id: 2, name: 'Silver Plan', amount: 3000, dailyReturnPercentage: 0.25 },
  { id: 3, name: 'Gold Plan', amount: 10000, dailyReturnPercentage: 0.25 },
  { id: 4, name: 'Platinum Plan', amount: 30000, dailyReturnPercentage: 0.25 },
];

export const WITHDRAWAL_THRESHOLD = 1000;
export const MOCK_ACCOUNT_DETAILS = {
  bankName: 'Moniepoint Microfinance Bank',
  accountNumber: '5050351765',
  accountName: 'Paul Odeh',
};

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, Investment, Plan, AuthContextType, Transaction, PastInvestment } from '../types';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const FAKE_GROWTH_INTERVAL_MS = 5000; // 5 seconds to simulate a day for demo purposes

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const storedUser = localStorage.getItem('user');
    return storedUser ? JSON.parse(storedUser) : null;
  });
  const [investment, setInvestment] = useState<Investment | null>(() => {
     const storedInvestment = localStorage.getItem('investment');
     return storedInvestment ? JSON.parse(storedInvestment) : null;
  });
  const [investmentHistory, setInvestmentHistory] = useState<PastInvestment[]>(() => {
      const storedHistory = localStorage.getItem('investmentHistory');
      return storedHistory ? JSON.parse(storedHistory) : [];
  });
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
      const storedTransactions = localStorage.getItem('transactions');
      return storedTransactions ? JSON.parse(storedTransactions) : [];
  });
  const [balance, setBalance] = useState({ total: 0, revenue: 0 });

  useEffect(() => {
    localStorage.setItem('transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('investmentHistory', JSON.stringify(investmentHistory));
  }, [investmentHistory]);


  const calculateRevenue = useCallback(() => {
    if (!investment) return { total: 0, revenue: 0 };
    
    const now = Date.now();
    const elapsedMs = now - investment.startDate;
    const daysPassed = Math.floor(elapsedMs / FAKE_GROWTH_INTERVAL_MS);
    
    const calculatedRevenue = investment.initialDeposit * 0.25 * daysPassed;
    const totalBalance = investment.initialDeposit + calculatedRevenue;

    return { total: totalBalance, revenue: calculatedRevenue };
  }, [investment]);


  useEffect(() => {
    if (investment) {
        const initialBalance = calculateRevenue();
        setBalance(initialBalance);
        const intervalId = setInterval(() => {
            setBalance(calculateRevenue());
        }, FAKE_GROWTH_INTERVAL_MS);
        return () => clearInterval(intervalId);
    } else {
        setBalance({ total: 0, revenue: 0 });
    }
  }, [investment, calculateRevenue]);

  const login = (emailOrPhone: string) => {
    const newUser: User = { id: 'user-123', emailOrPhone };
    setUser(newUser);
    localStorage.setItem('user', JSON.stringify(newUser));
    // Clear data from previous "sessions"
    localStorage.removeItem('investment');
    localStorage.removeItem('transactions');
    localStorage.removeItem('investmentHistory');
    setInvestment(null);
    setTransactions([]);
    setInvestmentHistory([]);
  };

  const logout = () => {
    setUser(null);
    setInvestment(null);
    setTransactions([]);
    setInvestmentHistory([]);
    localStorage.removeItem('user');
    localStorage.removeItem('investment');
    localStorage.removeItem('transactions');
    localStorage.removeItem('investmentHistory');
  };
  
  const startInvestment = (plan: Plan, payerDetails: { payerAccountName: string, payerBank: string }) => {
    const newInvestment: Investment = {
        planId: plan.id,
        initialDeposit: plan.amount,
        startDate: Date.now()
    };
    setInvestment(newInvestment);
    localStorage.setItem('investment', JSON.stringify(newInvestment));

    const newTransaction: Transaction = {
        id: `txn-${Date.now()}`,
        type: 'Deposit',
        amount: plan.amount,
        date: Date.now(),
        details: {
            planName: plan.name,
            payerAccountName: payerDetails.payerAccountName,
            payerBank: payerDetails.payerBank,
        }
    };
    setTransactions(prev => [newTransaction, ...prev]);
  };
  
  const withdraw = (amount: number, withdrawalDetails: { bankName: string, accountNumber: string, accountName: string }) => {
      if(!investment) return;
      const currentRevenue = balance.revenue;
      if(amount > currentRevenue) {
          alert("Withdrawal amount cannot exceed current revenue.");
          return;
      }

      // Archive the current investment cycle
      const pastInvestment: PastInvestment = {
        planId: investment.planId,
        initialDeposit: investment.initialDeposit,
        startDate: investment.startDate,
        endDate: Date.now(),
        finalRevenue: currentRevenue,
      };
      setInvestmentHistory(prev => [pastInvestment, ...prev]);

      // Simulate withdrawal by creating a new investment with reduced principal
      const newInitialDeposit = investment.initialDeposit + (currentRevenue - amount);
      const newInvestment: Investment = {
        ...investment,
        initialDeposit: newInitialDeposit,
        startDate: Date.now(), // Reset start date
      };
      setInvestment(newInvestment);
      localStorage.setItem('investment', JSON.stringify(newInvestment));

      const newTransaction: Transaction = {
        id: `txn-${Date.now()}`,
        type: 'Withdrawal',
        amount: amount,
        date: Date.now(),
        details: {
            beneficiaryAccountName: withdrawalDetails.accountName,
            beneficiaryAccountNumber: withdrawalDetails.accountNumber,
            beneficiaryBank: withdrawalDetails.bankName
        }
      };
      setTransactions(prev => [newTransaction, ...prev]);

      alert(`Successfully withdrew ₦${amount.toLocaleString()}`);
  }

  const value = { user, investment, login, logout, startInvestment, withdraw, balance, transactions, investmentHistory };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};